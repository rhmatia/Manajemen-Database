Nama: Rahmatia  
NIM: D0222304  
Kelas: Manajemen Basis Data C22

